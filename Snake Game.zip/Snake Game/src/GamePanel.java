import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;
public class GamePanel extends JPanel implements ActionListener {

    static final int screen_width=600;
    static final int screen_height=600;
    static final int unit_size=25; //size of a single object
    static final int game_units=(screen_width*screen_height)/unit_size;
    static final int delay=125; //tells how fast the game is running
    final int x[]=new int[game_units];
    final int y[]=new int[game_units];
    int body_parts=5;
    int score=0;
    int seedX; //x & y coordinates of the seed
    int seedY;
    char direction='R';
    boolean running=false;
    Timer timer;
    Random random;

    GamePanel(){
        random=new Random();
        this.setPreferredSize(new Dimension(screen_width,screen_height));
        this.setBackground(Color.black);
        this.setFocusable(true);
        this.addKeyListener(new MyKeyAdapter());
        startGame();
    }

    public void startGame() {
        newSeed();
        running=true;
        timer= new Timer(delay,this); //this value bec we are using action listener interface
        timer.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g); //super is an object of JPanel(built in parent class)
        draw(g);
    }

    public void draw(Graphics g) {
        if(running) {
            for (int i=0; i<screen_height/unit_size; i++) { //draws lines across game panel for grids
                g.drawLine(i*unit_size,0,i*unit_size,screen_height); //x axis
                g.drawLine(0,i*unit_size,screen_width,i*unit_size);  //y axis
            }
            g.setColor(Color.red);  //drawing seed
            g.fillOval(seedX,seedY,unit_size,unit_size);
            for(int i=0; i<body_parts; i++){ //drawing snake
                if(i==0){
                    g.setColor(new Color(50,0,250));
                    g.fillRect(x[i],y[i],unit_size,unit_size);
                }
                else{
                    g.setColor(new Color(0,50,200));
                    g.fillRect(x[i],y[i],unit_size,unit_size);
                }
            }
            g.setColor(Color.green);
            g.setFont(new Font("Serif",Font.BOLD,25));
            FontMetrics metrics = getFontMetrics(g.getFont());
            g.drawString("Score: "+score, ((screen_width-metrics.stringWidth("Score: \"+score"))/2),g.getFont().getSize());

        }
        else {
            gameOver(g);
        }
    }

    public void move() {
        for(int i=body_parts; i>0; i--){
            x[i]=x[i-1];
            y[i]=y[i-1];

        }
        switch (direction){
            case 'U':
                y[0]=y[0]-unit_size;
                break;
            case 'D':
                y[0]=y[0]+unit_size;
                break;
            case 'L':
                x[0]=x[0]-unit_size;
                break;
            case 'R':
                x[0]=x[0]+unit_size;
                break;
        }

    }
    public void newSeed() {

        seedX= random.nextInt((int)screen_width/unit_size)*unit_size;
        seedY= random.nextInt((int)screen_height/unit_size)*unit_size;
    }

    public void checkSeed() {
        if((x[0]==seedX)&&(y[0]==seedY)) {
            body_parts++;
            score++;
            newSeed();
        }
    }

    public void checkCollisions() {
        //checking if head touches its body
        for(int i=body_parts;i>0;i--) {
            if((x[0]==x[i])&&(y[0]==y[i])) {
                running=false;
            }
        }

        if(x[0]<0) {
            running=false;
        }

        if(x[0]>screen_width) {
            running=false;
        }

        if(y[0]<0) {
            running=false;
        }

        if(y[0]>screen_height) {
            running=false;
        }

        if(!running) {
            timer.stop();
        }
    }

    public void gameOver(Graphics g) {
        g.setColor(Color.red);
        g.setFont(new Font("Ink Free",Font.BOLD,75));
        FontMetrics metrics = getFontMetrics(g.getFont());
        g.drawString("Game Over", ((screen_width-metrics.stringWidth("Game Over"))/2),screen_height/2);

        g.setColor(Color.green);
        g.setFont(new Font("Serif",Font.BOLD,25));
        FontMetrics metric = getFontMetrics(g.getFont());
        g.drawString("Score: "+score, ((screen_width-metric.stringWidth("Score: "+score))/2),g.getFont().getSize());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(running) {
            move();
            checkSeed();
            checkCollisions();
        }
        repaint();
    }

    public class MyKeyAdapter extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            switch(e.getKeyCode()) {

                case KeyEvent.VK_LEFT:
                    if(direction!='R') {
                        direction='L';
                    }
                    break;

                case KeyEvent.VK_RIGHT:
                    if(direction!='L') {
                        direction='R';
                    }
                    break;

                case KeyEvent.VK_UP:
                    if(direction!='D') {
                        direction='U';
                    }
                    break;

                case KeyEvent.VK_DOWN:
                    if(direction!='U') {
                        direction='D';
                    }
                    break;
            }
        }
    }}